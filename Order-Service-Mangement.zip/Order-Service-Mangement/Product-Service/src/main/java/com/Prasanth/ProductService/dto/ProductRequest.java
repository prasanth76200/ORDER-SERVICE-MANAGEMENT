package com.Prasanth.ProductService.dto;

import java.math.BigDecimal;

public record ProductRequest(String productId,String productName,String productDescription,BigDecimal productPrice) {
}