package com.Prasanth.ProductService.service.impl;

import com.Prasanth.ProductService.dto.ProductRequest;
import com.Prasanth.ProductService.dto.ProductResponse;
import com.Prasanth.ProductService.model.Product;
import com.Prasanth.ProductService.repository.ProductRepo;
import com.Prasanth.ProductService.service.ProductService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductServiceImpl implements ProductService {

    private final ProductRepo productRepo;


    @Override
    public ProductResponse createProduct(ProductRequest productRequest) {
        Product product = Product.builder()
                .productName(productRequest.productName())
                .productDescription(productRequest.productDescription())
                .productPrice(productRequest.productPrice())
                .build();
        productRepo.save(product);
        log.info("Created product : {}", product);
        return new ProductResponse(product.getProductId(), product.getProductName(), product.getProductDescription(), product.getProductPrice());
    }

    @Override
    public List<ProductResponse> getAllProducts() {
        return productRepo.findAll()
                .stream()
                .map(product -> new ProductResponse(product.getProductId(), product.getProductName(), product.getProductDescription(), product.getProductPrice()))
                .toList();
    }
}
