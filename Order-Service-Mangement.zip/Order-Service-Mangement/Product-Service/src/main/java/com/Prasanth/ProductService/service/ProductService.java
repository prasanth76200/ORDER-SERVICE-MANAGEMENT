package com.Prasanth.ProductService.service;



import com.Prasanth.ProductService.dto.ProductRequest;
import com.Prasanth.ProductService.dto.ProductResponse;

import java.util.List;

public interface ProductService {
    public ProductResponse createProduct(ProductRequest productRequest);
    public List<ProductResponse> getAllProducts();
}
