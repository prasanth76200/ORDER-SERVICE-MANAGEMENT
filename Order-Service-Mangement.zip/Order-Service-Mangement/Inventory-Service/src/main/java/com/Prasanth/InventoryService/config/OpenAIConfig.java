package com.Prasanth.InventoryService.config;



import io.swagger.v3.oas.models.ExternalDocumentation;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenAIConfig {
    @Bean
    public OpenAPI inventoryServiceOpenAPI() {
        return new OpenAPI()
                .info(new Info().title("Inventory Service API")
                        .description("This is the Rest API for Inventory Service")
                        .version("V0.0.1")
                        .license(new License()))
                .externalDocs(new ExternalDocumentation()
                        .description("Refer this Order Inventory wiki")
                        .url("https://springdoc.org/"));
    }
}
