package com.Prasanth.InventoryService.dto;

public record InventoryRequest(Long inventoryId,String skuCode,Integer quantity) {
}
