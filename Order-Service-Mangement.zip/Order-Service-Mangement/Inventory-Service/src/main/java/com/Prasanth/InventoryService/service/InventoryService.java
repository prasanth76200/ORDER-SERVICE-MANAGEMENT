package com.Prasanth.InventoryService.service;

import com.Prasanth.InventoryService.dto.InventoryRequest;
import com.Prasanth.InventoryService.model.Inventory;

public interface InventoryService {
    public boolean isInStock(String skuCode, Integer quantity);
    public Inventory getInventory(InventoryRequest inventoryRequest);
}
