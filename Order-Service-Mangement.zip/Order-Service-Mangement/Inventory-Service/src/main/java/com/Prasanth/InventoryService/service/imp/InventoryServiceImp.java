package com.Prasanth.InventoryService.service.imp;

import com.Prasanth.InventoryService.dto.InventoryRequest;
import com.Prasanth.InventoryService.model.Inventory;
import com.Prasanth.InventoryService.repo.InventoryRepo;
import com.Prasanth.InventoryService.service.InventoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class InventoryServiceImp implements InventoryService {
    private final InventoryRepo inventoryRepo;

    @Override
    public boolean isInStock(String skuCode, Integer quantity) {
        return inventoryRepo.existsBySkuCodeAndQuantityIsGreaterThanEqual(skuCode,quantity);
    }

    @Override
    public Inventory getInventory(InventoryRequest inventoryRequest) {
        Inventory inventory = new Inventory();
        inventory.setQuantity(inventoryRequest.quantity());
        inventory.setSkuCode(inventoryRequest.skuCode());
       return inventoryRepo.save(inventory);
    }


}
