package com.Prasanth.OrderService.service;


import com.Prasanth.OrderService.dto.OrderRequest;

public interface OrderService {
    public void placeOrder(OrderRequest orderRequest);
}
