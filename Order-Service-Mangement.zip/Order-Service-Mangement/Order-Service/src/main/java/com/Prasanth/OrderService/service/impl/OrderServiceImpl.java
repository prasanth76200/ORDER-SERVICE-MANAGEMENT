package com.Prasanth.OrderService.service.impl;


import com.Prasanth.OrderService.client.InventoryClient;
import com.Prasanth.OrderService.dto.OrderRequest;
import com.Prasanth.OrderService.model.OrderDetails;
import com.Prasanth.OrderService.repository.OrderRepo;
import com.Prasanth.OrderService.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {
    private final OrderRepo orderRepo;
    private final InventoryClient inventoryClient;


    @Override
    public void placeOrder(OrderRequest orderRequest) {
       var isProductInStock =  inventoryClient.isInStock(orderRequest.skuCode(), orderRequest.quantity());

       if(isProductInStock){
           OrderDetails orderDetails = new OrderDetails();
           orderDetails.setOrderNumber(UUID.randomUUID().toString());
           orderDetails.setPrice(orderRequest.price());
           orderDetails.setQuantity(orderRequest.quantity());
           orderRepo.save(orderDetails);
       }else{
           throw new RuntimeException(orderRequest.skuCode() + "Product is not in stock");
       }


    }
}
